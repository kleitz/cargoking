#Flat Line Icons Webfont by Pete R.
180+ high quality & minimal icons webfont for Bootstrap Framework
Created by [Pete R.](http://www.thepetedesign.com), Founder of [BucketListly](http://www.bucketlistly.com)

[![Flat Line Icons Webfont](http://www.thepetedesign.com/images/flat_line_icons_image.jpg "Flat Line Icons Webfont")](http://www.thepetedesign.com/flatline_icons)

## Preview
[View demo](http://www.thepetedesign.com/flatline_icons)
[Buy Full Package](http://www.thepetedesign.com/flatline_icons#full-buy-now)

## Compatibility
Modern browsers such as Chrome, Firefox, and Safari on both desktop and smartphones have been tested. I have not tested this on IE but should support it fine.

## Free Package
This is a free package which includes 50 icons in AI, EPS and Webfont (WOFF, EOT, SVG, TTF) formats. Demo files are also included in the package.

## Want more Icons?
For a full 180+ high quality package, you can buy them here only for US$5! [Buy them here](http://www.thepetedesign.com/flatline_icons#full-buy-now)

If you want to see more of my plugins, visit [The Pete Design](http://www.thepetedesign.com/#design), or follow me on [Twitter](http://www.twitter.com/peachananr) and [Github](http://www.github.com/peachananr).
